using Workerd = import "/workerd/workerd.capnp";
const config :Workerd.Config = (services = [(name = "main", worker = .worker)], sockets = [(name = "http", address = "127.0.0.1:47253", http = (), service = "main")]);
const worker :Workerd.Worker = (compatibilityDate = "2026-08-20", modules = [(name = "main", esModule = embed "bundle.mjs")]);
