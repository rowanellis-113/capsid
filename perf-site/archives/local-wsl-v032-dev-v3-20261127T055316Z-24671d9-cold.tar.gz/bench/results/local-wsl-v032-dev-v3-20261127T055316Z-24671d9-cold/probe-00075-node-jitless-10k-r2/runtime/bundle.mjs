function fn00000(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00001 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00002 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00003(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00004 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00005 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00006(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00007 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00008 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00009(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00010 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00011 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00012(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00013 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00014 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00015(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00016 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00017 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00018(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00019 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00020 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00021(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00022 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00023 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00024(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00025 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00026 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00027(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00028 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00029 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00030(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00031 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00032 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
function fn00033(seed) {
  const items = [];
  let total = seed;
  for (let i = 0; i < 16; i++) {
    const weight = (i * 37 + seed) % 97;
    const item = { id: "item-" + i, weight, tags: ["alpha", "beta", i % 3 === 0 ? "gamma" : "delta"] };
    total += weight * (i % 4 + 1);
    items.push(item);
  }
  return { seed, total, count: items.length, ratio: total / (seed + 1) };
}
class P00034 {
  constructor(seed) { this.seed = seed; this.log = []; }
  step(n) {
    const v = (n * 41 + this.seed) % 89;
    this.log.push(v);
    return v;
  }
  summarize() {
    return this.log.reduce((a, b) => a + b, 0) / Math.max(1, this.log.length);
  }
}
const p00035 = (rows) =>
  rows
    .map((r) => ({ ...r, w: r.v * (r.k % 5 + 1) }))
    .filter((r) => r.w > 10)
    .sort((a, b) => b.w - a.w)
    .slice(0, 8)
    .reduce((acc, r) => acc + r.w, 0);
import { createServer } from "node:http";
const server = createServer((req, res) => {
  const q = fn00000(7);
  res.setHeader("content-type", "application/json");
  res.end(JSON.stringify({ status: "ok", total: q.total, count: q.count }));
});
server.listen(40107, "127.0.0.1", () => console.log("READY"));
